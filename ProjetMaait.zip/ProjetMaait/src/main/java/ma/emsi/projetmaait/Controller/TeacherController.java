package ma.emsi.projetmaait.Controller;

import lombok.AllArgsConstructor;
import ma.emsi.projetmaait.Entities.Teacher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import ma.emsi.projetmaait.Repository.TeachersRepository;


@Controller
public class TeacherController {


    @Autowired TeachersRepository teacherRepository;

    @GetMapping("/indexTeacher")
    public String indexTeacher(Model model,
                                         @RequestParam(name = "page", defaultValue = "0") int page,
                                         @RequestParam(name = "size", defaultValue = "3") int size,
                                         @RequestParam(name = "keyword", defaultValue = "") String kw) {
        int pageTeacherRepository;
        Page<Teacher> teacherPage = teacherRepository.findAll(PageRequest.of(page, size));
        model.addAttribute("listTeachers", teacherPage.getContent());

        model.addAttribute("pages", new int[teacherPage.getTotalPages()]);
        model.addAttribute("currentPage", page);
        model.addAttribute("keyword", kw);
        return "teachers";
    }
    @GetMapping("/deleteTeacher")
    public String deleteTeacher(@RequestParam(name = "id") long id,
                                @RequestParam(name = "keyword", defaultValue = "") String keyword,
                                @RequestParam(name = "size", defaultValue = "3") int size,
                                @RequestParam(name = "page", defaultValue = "0") int page) {
        teacherRepository.deleteById(id);
        return "redirect:/indexTeacher?page=" + page + "&keyword=" + keyword+"&size=" + size   ;
    }

    @GetMapping("/")
    public String index() {
        return "redirect:/indexTeacher";
    }

    @GetMapping("/formTeacher")
    public String formTeacher(Model model) {
        model.addAttribute("teacher",
                new Teacher());
        return "formTeacher";
    }

    @PostMapping("/saveTeacher")
    public String saveTeacher(Teacher teacher) {
        teacherRepository.save(teacher);
        return "redirect:/";
    }

}
