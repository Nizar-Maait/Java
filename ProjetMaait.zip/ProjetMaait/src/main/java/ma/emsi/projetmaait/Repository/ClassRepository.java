package ma.emsi.projetmaait.Repository;

import ma.emsi.projetmaait.Entities.Class;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ClassRepository extends JpaRepository<Class, Long> {

    List<Class> findByClassName(String className);
    List<Class> findByClassNameContains(String className);
    Page<Class> findByClassNameContains(String className, Pageable pageable);
}
