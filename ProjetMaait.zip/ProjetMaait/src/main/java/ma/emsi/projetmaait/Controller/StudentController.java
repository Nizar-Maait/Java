package ma.emsi.projetmaait.Controller;

import lombok.AllArgsConstructor;
import ma.emsi.projetmaait.Entities.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import ma.emsi.projetmaait.Repository.StudentRepository;

@Controller
public class StudentController {

    @Autowired
    private StudentRepository studentRepository;

    @GetMapping("/indexStudent")
    public String indexStudent(Model model,
                               @RequestParam(name = "page", defaultValue = "0") int page,
                               @RequestParam(name = "size", defaultValue = "3") int size,
                               @RequestParam(name = "keyword", defaultValue = "") String keyword) {
        Page<Student> studentPage = studentRepository.findByFullNameContains(keyword, PageRequest.of(page, size));
        model.addAttribute("studentList", studentPage.getContent());
        model.addAttribute("pages", new int[studentPage.getTotalPages()]);
        model.addAttribute("currentPage", page);
        model.addAttribute("keyword", keyword);
        return "students";
    }

    @GetMapping("/deleteStudent")
    public String deleteStudent(@RequestParam(name = "id") long id,
                                @RequestParam(name = "keyword", defaultValue = "") String keyword,
                                @RequestParam(name = "size", defaultValue = "3") int size,
                                @RequestParam(name = "page", defaultValue = "0") int page) {
        studentRepository.deleteById(id);
        return "redirect:/indexStudent?page=" + page + "&keyword=" + keyword + "&size=" + size;
    }

    @GetMapping("/formStudent")
    public String formStudent(Model model) {
        model.addAttribute("student", new Student());
        return "formStudent";
    }

    @PostMapping("/saveStudent")
    public String saveStudent(Student student) {
        studentRepository.save(student);
        return "redirect:/indexStudent";
    }
}
