package ma.emsi.projetmaait.Repository;

import ma.emsi.projetmaait.Entities.Teacher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TeachersRepository extends JpaRepository<Teacher,Long> {


  // Page<Teacher> findByNameContains(String kw, PageRequest of);
}
