package ma.emsi.projetmaait.Entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;


// lombok

@Data @AllArgsConstructor @NoArgsConstructor
@Entity
public class Student extends User{




    @Column(name ="registration_N", unique = true)
    private String registrationNumber;
    @Column(name = "Name", length=30, nullable = false )
    private String fullName;
    @Temporal(TemporalType.DATE) // date
    private Date birthday;
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastConnection;

}
