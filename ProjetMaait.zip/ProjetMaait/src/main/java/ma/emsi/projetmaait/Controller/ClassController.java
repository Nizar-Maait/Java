package ma.emsi.projetmaait.Controller;

import lombok.AllArgsConstructor;
import ma.emsi.projetmaait.Entities.Class;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import ma.emsi.projetmaait.Repository.ClassRepository;

@Controller
public class ClassController {

    @Autowired
    private ClassRepository classRepository;

    @GetMapping("/indexClass")
    public String indexClass(Model model,
                             @RequestParam(name = "page", defaultValue = "0") int page,
                             @RequestParam(name = "size", defaultValue = "3") int size,
                             @RequestParam(name = "keyword", defaultValue = "") String keyword) {
        Page<Class> classPage = classRepository.findByClassNameContains(keyword, PageRequest.of(page, size));
        model.addAttribute("classList", classPage.getContent());
        model.addAttribute("pages", new int[classPage.getTotalPages()]);
        model.addAttribute("currentPage", page);
        model.addAttribute("keyword", keyword);
        return "classes";
    }

    @GetMapping("/deleteClass")
    public String deleteClass(@RequestParam(name = "id") long id,
                              @RequestParam(name = "keyword", defaultValue = "") String keyword,
                              @RequestParam(name = "size", defaultValue = "3") int size,
                              @RequestParam(name = "page", defaultValue = "0") int page) {
        classRepository.deleteById(id);
        return "redirect:/indexClass?page=" + page + "&keyword=" + keyword + "&size=" + size;
    }

    @GetMapping("/formClass")
    public String formClass(Model model) {
        model.addAttribute("class", new Class());
        return "formClass";
    }

    /*@PostMapping("/saveClass")
    public String saveClass(Class classObj) {
        Class save = ClassRepository.save(classObj);
        return "redirect:/";
    }*/
}
