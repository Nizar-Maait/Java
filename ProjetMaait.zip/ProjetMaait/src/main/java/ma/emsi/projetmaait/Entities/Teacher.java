package ma.emsi.projetmaait.Entities;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Collate;

import java.util.Collection;
@Entity
@Data @NoArgsConstructor @AllArgsConstructor

public class Teacher extends User{

    private String specialite;

}

