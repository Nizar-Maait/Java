package ma.emsi.projetmaait.Repository;

import ma.emsi.projetmaait.Entities.Student;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Date;
import java.util.List;

public interface StudentRepository extends JpaRepository<Student, Long> {
    List<Student> findByFullName(String fullName);

    List<Student> findByRegistrationNumber(String registrationNumber);

    List<Student> findByFullNameContains(String fullName);

    List<Student> findByBirthday(java.util.Date birthday);

    Page<Student> findByFullNameContains(String fullName, Pageable pageable);
}